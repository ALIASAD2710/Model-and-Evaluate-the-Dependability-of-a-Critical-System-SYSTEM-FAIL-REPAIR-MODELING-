#ifndef _VERSION_2FS_PVMODEL_
#define _VERSION_2FS_PVMODEL_
#include "VERSION_2FSPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Atomic/VERSION_2/VERSION_2SAN.h"
class VERSION_2FSPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  VERSION_2FSPVModel(bool expandtimepoints);
};

#endif
