#include "VERSION_2FSPVModel.h"

VERSION_2FSPVModel::VERSION_2FSPVModel(bool expandTimeArrays) {
  TheModel=new VERSION_2SAN();
  DefineName("VERSION_2FSPVModel");
  CreatePVList(2, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* VERSION_2FSPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new VERSION_2FSPV0(timeindex);
    break;
  case 1:
    return new VERSION_2FSPV1(timeindex);
    break;
  }
  return NULL;
}
