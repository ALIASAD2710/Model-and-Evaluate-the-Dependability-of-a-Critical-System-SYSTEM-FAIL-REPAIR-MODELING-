

// This C++ file was created by SanEditor

#include "Atomic/VERSION_2/VERSION_2SAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         VERSION_2SAN Constructor             
******************************************************************/


VERSION_2SAN::VERSION_2SAN(){


  Activity* InitialActionList[13]={
    &RESTORE_A, //0
    &REPAIR_START, //1
    &RESTORE_B, //2
    &REPAIR_FINISHED, //3
    &SYSTEM_FAILURE_B_C, //4
    &RESTORE_C, //5
    &STOP_RESTORE, //6
    &FAIL_A, //7
    &REPAIR_ACT_A, //8
    &FAIL_B, //9
    &REPAIR_ACT_B, //10
    &REPAIR_C_ACT, //11
    &FAIL_C  // 12
  };

  BaseGroupClass* InitialGroupList[13]={
    (BaseGroupClass*) &(FAIL_A), 
    (BaseGroupClass*) &(REPAIR_ACT_A), 
    (BaseGroupClass*) &(FAIL_B), 
    (BaseGroupClass*) &(REPAIR_ACT_B), 
    (BaseGroupClass*) &(REPAIR_C_ACT), 
    (BaseGroupClass*) &(FAIL_C), 
    (BaseGroupClass*) &(RESTORE_A), 
    (BaseGroupClass*) &(REPAIR_START), 
    (BaseGroupClass*) &(RESTORE_B), 
    (BaseGroupClass*) &(REPAIR_FINISHED), 
    (BaseGroupClass*) &(SYSTEM_FAILURE_B_C), 
    (BaseGroupClass*) &(RESTORE_C), 
    (BaseGroupClass*) &(STOP_RESTORE)
  };

  BUFFER_A = new Place("BUFFER_A" ,0);
  WORKING_SYSTEM = new Place("WORKING_SYSTEM" ,1);
  FAILURE_BUFFER = new Place("FAILURE_BUFFER" ,0);
  FAILED_A = new Place("FAILED_A" ,0);
  SYSTEM_FAILURE = new Place("SYSTEM_FAILURE" ,0);
  PLACE_A = new Place("PLACE_A" ,1);
  FAILED_B = new Place("FAILED_B" ,0);
  PLACE_B = new Place("PLACE_B" ,2);
  REPAIRING_SYSTEM = new Place("REPAIRING_SYSTEM" ,0);
  SYSTEM_MAINTAINANCE = new Place("SYSTEM_MAINTAINANCE" ,0);
  FAILED_B_C = new Place("FAILED_B_C" ,0);
  BUFFER_B = new Place("BUFFER_B" ,0);
  PLACE_C = new Place("PLACE_C" ,3);
  BUFFER_C = new Place("BUFFER_C" ,0);
  FAILED_C = new Place("FAILED_C" ,0);
  BaseStateVariableClass* InitialPlaces[15]={
    BUFFER_A,  // 0
    WORKING_SYSTEM,  // 1
    FAILURE_BUFFER,  // 2
    FAILED_A,  // 3
    SYSTEM_FAILURE,  // 4
    PLACE_A,  // 5
    FAILED_B,  // 6
    PLACE_B,  // 7
    REPAIRING_SYSTEM,  // 8
    SYSTEM_MAINTAINANCE,  // 9
    FAILED_B_C,  // 10
    BUFFER_B,  // 11
    PLACE_C,  // 12
    BUFFER_C,  // 13
    FAILED_C   // 14
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("VERSION_2", 15, InitialPlaces, 
                        0, InitialROPlaces, 
                        13, InitialActionList, 13, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[34][2]={ 
    {0,0}, {8,0}, {5,0}, {4,1}, {1,1}, {9,1}, {2,1}, {8,2}, {11,2}, 
    {7,2}, {8,3}, {9,3}, {4,4}, {10,4}, {8,5}, {13,5}, {12,5}, 
    {8,6}, {1,6}, {5,7}, {0,7}, {3,7}, {4,7}, {3,8}, {7,9}, {6,9}, 
    {10,9}, {11,9}, {6,10}, {14,11}, {12,12}, {10,12}, {13,12}, 
    {14,12}
  };
  for(int n=0;n<34;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[30][2]={ 
    {0,0}, {8,0}, {4,1}, {8,2}, {11,2}, {3,3}, {9,3}, {14,3}, 
    {6,3}, {10,4}, {8,5}, {13,5}, {0,6}, {11,6}, {13,6}, {8,6}, 
    {5,7}, {1,7}, {3,8}, {9,8}, {6,8}, {7,9}, {1,9}, {6,10}, 
    {9,10}, {14,10}, {9,11}, {14,11}, {12,12}, {1,12}
  };
  for(int n=0;n<30;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<13;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void VERSION_2SAN::CustomInitialization() {

}
VERSION_2SAN::~VERSION_2SAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void VERSION_2SAN::assignPlacesToActivitiesInst(){
  RESTORE_A.BUFFER_A = (Place*) LocalStateVariables[0];
  RESTORE_A.REPAIRING_SYSTEM = (Place*) LocalStateVariables[8];
  RESTORE_A.PLACE_A = (Place*) LocalStateVariables[5];
  REPAIR_START.SYSTEM_FAILURE = (Place*) LocalStateVariables[4];
  REPAIR_START.WORKING_SYSTEM = (Place*) LocalStateVariables[1];
  REPAIR_START.SYSTEM_MAINTAINANCE = (Place*) LocalStateVariables[9];
  REPAIR_START.FAILURE_BUFFER = (Place*) LocalStateVariables[2];
  RESTORE_B.REPAIRING_SYSTEM = (Place*) LocalStateVariables[8];
  RESTORE_B.BUFFER_B = (Place*) LocalStateVariables[11];
  RESTORE_B.PLACE_B = (Place*) LocalStateVariables[7];
  REPAIR_FINISHED.FAILED_A = (Place*) LocalStateVariables[3];
  REPAIR_FINISHED.SYSTEM_MAINTAINANCE = (Place*) LocalStateVariables[9];
  REPAIR_FINISHED.FAILED_C = (Place*) LocalStateVariables[14];
  REPAIR_FINISHED.FAILED_B = (Place*) LocalStateVariables[6];
  REPAIR_FINISHED.REPAIRING_SYSTEM = (Place*) LocalStateVariables[8];
  SYSTEM_FAILURE_B_C.FAILED_B_C = (Place*) LocalStateVariables[10];
  SYSTEM_FAILURE_B_C.SYSTEM_FAILURE = (Place*) LocalStateVariables[4];
  RESTORE_C.REPAIRING_SYSTEM = (Place*) LocalStateVariables[8];
  RESTORE_C.BUFFER_C = (Place*) LocalStateVariables[13];
  RESTORE_C.PLACE_C = (Place*) LocalStateVariables[12];
  STOP_RESTORE.BUFFER_A = (Place*) LocalStateVariables[0];
  STOP_RESTORE.BUFFER_B = (Place*) LocalStateVariables[11];
  STOP_RESTORE.BUFFER_C = (Place*) LocalStateVariables[13];
  STOP_RESTORE.REPAIRING_SYSTEM = (Place*) LocalStateVariables[8];
  STOP_RESTORE.WORKING_SYSTEM = (Place*) LocalStateVariables[1];
}
void VERSION_2SAN::assignPlacesToActivitiesTimed(){
  FAIL_A.PLACE_A = (Place*) LocalStateVariables[5];
  FAIL_A.WORKING_SYSTEM = (Place*) LocalStateVariables[1];
  FAIL_A.BUFFER_A = (Place*) LocalStateVariables[0];
  FAIL_A.FAILED_A = (Place*) LocalStateVariables[3];
  FAIL_A.SYSTEM_FAILURE = (Place*) LocalStateVariables[4];
  REPAIR_ACT_A.FAILED_A = (Place*) LocalStateVariables[3];
  REPAIR_ACT_A.SYSTEM_MAINTAINANCE = (Place*) LocalStateVariables[9];
  REPAIR_ACT_A.FAILED_B = (Place*) LocalStateVariables[6];
  FAIL_B.PLACE_B = (Place*) LocalStateVariables[7];
  FAIL_B.WORKING_SYSTEM = (Place*) LocalStateVariables[1];
  FAIL_B.FAILED_B = (Place*) LocalStateVariables[6];
  FAIL_B.FAILED_B_C = (Place*) LocalStateVariables[10];
  FAIL_B.BUFFER_B = (Place*) LocalStateVariables[11];
  REPAIR_ACT_B.FAILED_B = (Place*) LocalStateVariables[6];
  REPAIR_ACT_B.SYSTEM_MAINTAINANCE = (Place*) LocalStateVariables[9];
  REPAIR_ACT_B.FAILED_C = (Place*) LocalStateVariables[14];
  REPAIR_C_ACT.SYSTEM_MAINTAINANCE = (Place*) LocalStateVariables[9];
  REPAIR_C_ACT.FAILED_C = (Place*) LocalStateVariables[14];
  FAIL_C.PLACE_C = (Place*) LocalStateVariables[12];
  FAIL_C.WORKING_SYSTEM = (Place*) LocalStateVariables[1];
  FAIL_C.FAILED_B_C = (Place*) LocalStateVariables[10];
  FAIL_C.BUFFER_C = (Place*) LocalStateVariables[13];
  FAIL_C.FAILED_C = (Place*) LocalStateVariables[14];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================RESTORE_AActivity========================*/


VERSION_2SAN::RESTORE_AActivity::RESTORE_AActivity(){
  ActivityInitialize("RESTORE_A",6,Instantaneous , RaceEnabled, 3,2, false);
}

void VERSION_2SAN::RESTORE_AActivity::LinkVariables(){
  BUFFER_A->Register(&BUFFER_A_Mobius_Mark);
  REPAIRING_SYSTEM->Register(&REPAIRING_SYSTEM_Mobius_Mark);
  PLACE_A->Register(&PLACE_A_Mobius_Mark);
}

bool VERSION_2SAN::RESTORE_AActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(BUFFER_A_Mobius_Mark)) >=1)&&((*(REPAIRING_SYSTEM_Mobius_Mark)) >=1));
  return NewEnabled;
}

double VERSION_2SAN::RESTORE_AActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::RESTORE_AActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::RESTORE_AActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::RESTORE_AActivity::SampleDistribution(){
  return 0;
}

double* VERSION_2SAN::RESTORE_AActivity::ReturnDistributionParameters(){
    return NULL;
}

int VERSION_2SAN::RESTORE_AActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::RESTORE_AActivity::Fire(){
  (*(BUFFER_A_Mobius_Mark))--;
  (*(REPAIRING_SYSTEM_Mobius_Mark))--;
  (*(PLACE_A_Mobius_Mark))++;
  (*(REPAIRING_SYSTEM_Mobius_Mark))++;
  return this;
}

/*======================REPAIR_STARTActivity========================*/


VERSION_2SAN::REPAIR_STARTActivity::REPAIR_STARTActivity(){
  ActivityInitialize("REPAIR_START",7,Instantaneous , RaceEnabled, 4,1, false);
}

void VERSION_2SAN::REPAIR_STARTActivity::LinkVariables(){
  SYSTEM_FAILURE->Register(&SYSTEM_FAILURE_Mobius_Mark);
  WORKING_SYSTEM->Register(&WORKING_SYSTEM_Mobius_Mark);
  SYSTEM_MAINTAINANCE->Register(&SYSTEM_MAINTAINANCE_Mobius_Mark);
  FAILURE_BUFFER->Register(&FAILURE_BUFFER_Mobius_Mark);
}

bool VERSION_2SAN::REPAIR_STARTActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(SYSTEM_FAILURE_Mobius_Mark)) >=1));
  return NewEnabled;
}

double VERSION_2SAN::REPAIR_STARTActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::REPAIR_STARTActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::REPAIR_STARTActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::REPAIR_STARTActivity::SampleDistribution(){
  return 0;
}

double* VERSION_2SAN::REPAIR_STARTActivity::ReturnDistributionParameters(){
    return NULL;
}

int VERSION_2SAN::REPAIR_STARTActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::REPAIR_STARTActivity::Fire(){
  (*(SYSTEM_FAILURE_Mobius_Mark))--;
  WORKING_SYSTEM->Mark() = 0;
SYSTEM_MAINTAINANCE->Mark() = 1;
if (1 > FAILURE_BUFFER->Mark() ) FAILURE_BUFFER->Mark() = 1;
  return this;
}

/*======================RESTORE_BActivity========================*/


VERSION_2SAN::RESTORE_BActivity::RESTORE_BActivity(){
  ActivityInitialize("RESTORE_B",8,Instantaneous , RaceEnabled, 3,2, false);
}

void VERSION_2SAN::RESTORE_BActivity::LinkVariables(){
  REPAIRING_SYSTEM->Register(&REPAIRING_SYSTEM_Mobius_Mark);
  BUFFER_B->Register(&BUFFER_B_Mobius_Mark);
  PLACE_B->Register(&PLACE_B_Mobius_Mark);
}

bool VERSION_2SAN::RESTORE_BActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(REPAIRING_SYSTEM_Mobius_Mark)) >=1)&&((*(BUFFER_B_Mobius_Mark)) >=1));
  return NewEnabled;
}

double VERSION_2SAN::RESTORE_BActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::RESTORE_BActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::RESTORE_BActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::RESTORE_BActivity::SampleDistribution(){
  return 0;
}

double* VERSION_2SAN::RESTORE_BActivity::ReturnDistributionParameters(){
    return NULL;
}

int VERSION_2SAN::RESTORE_BActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::RESTORE_BActivity::Fire(){
  (*(REPAIRING_SYSTEM_Mobius_Mark))--;
  (*(BUFFER_B_Mobius_Mark))--;
  (*(PLACE_B_Mobius_Mark))++;
  (*(REPAIRING_SYSTEM_Mobius_Mark))++;
  return this;
}

/*======================REPAIR_FINISHEDActivity========================*/


VERSION_2SAN::REPAIR_FINISHEDActivity::REPAIR_FINISHEDActivity(){
  ActivityInitialize("REPAIR_FINISHED",9,Instantaneous , RaceEnabled, 2,4, false);
}

void VERSION_2SAN::REPAIR_FINISHEDActivity::LinkVariables(){
  FAILED_A->Register(&FAILED_A_Mobius_Mark);
  SYSTEM_MAINTAINANCE->Register(&SYSTEM_MAINTAINANCE_Mobius_Mark);
  FAILED_C->Register(&FAILED_C_Mobius_Mark);
  FAILED_B->Register(&FAILED_B_Mobius_Mark);
  REPAIRING_SYSTEM->Register(&REPAIRING_SYSTEM_Mobius_Mark);
}

bool VERSION_2SAN::REPAIR_FINISHEDActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((FAILED_A->Mark() == 0) && (SYSTEM_MAINTAINANCE->Mark() == 1) && (FAILED_C->Mark() == 0) or (FAILED_B->Mark() == 0)));
  return NewEnabled;
}

double VERSION_2SAN::REPAIR_FINISHEDActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::REPAIR_FINISHEDActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::REPAIR_FINISHEDActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::REPAIR_FINISHEDActivity::SampleDistribution(){
  return 0;
}

double* VERSION_2SAN::REPAIR_FINISHEDActivity::ReturnDistributionParameters(){
    return NULL;
}

int VERSION_2SAN::REPAIR_FINISHEDActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::REPAIR_FINISHEDActivity::Fire(){
  SYSTEM_MAINTAINANCE->Mark()--;
  (*(REPAIRING_SYSTEM_Mobius_Mark))++;
  return this;
}

/*======================SYSTEM_FAILURE_B_CActivity========================*/


VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::SYSTEM_FAILURE_B_CActivity(){
  ActivityInitialize("SYSTEM_FAILURE_B_C",10,Instantaneous , RaceEnabled, 2,1, false);
}

void VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::LinkVariables(){
  FAILED_B_C->Register(&FAILED_B_C_Mobius_Mark);
  SYSTEM_FAILURE->Register(&SYSTEM_FAILURE_Mobius_Mark);
}

bool VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((FAILED_B_C -> Mark() == 5));
  return NewEnabled;
}

double VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::SampleDistribution(){
  return 0;
}

double* VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::ReturnDistributionParameters(){
    return NULL;
}

int VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::SYSTEM_FAILURE_B_CActivity::Fire(){
  FAILED_B_C -> Mark() = 0;
  (*(SYSTEM_FAILURE_Mobius_Mark))++;
  return this;
}

/*======================RESTORE_CActivity========================*/


VERSION_2SAN::RESTORE_CActivity::RESTORE_CActivity(){
  ActivityInitialize("RESTORE_C",11,Instantaneous , RaceEnabled, 3,2, false);
}

void VERSION_2SAN::RESTORE_CActivity::LinkVariables(){
  REPAIRING_SYSTEM->Register(&REPAIRING_SYSTEM_Mobius_Mark);
  BUFFER_C->Register(&BUFFER_C_Mobius_Mark);
  PLACE_C->Register(&PLACE_C_Mobius_Mark);
}

bool VERSION_2SAN::RESTORE_CActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(REPAIRING_SYSTEM_Mobius_Mark)) >=1)&&((*(BUFFER_C_Mobius_Mark)) >=1));
  return NewEnabled;
}

double VERSION_2SAN::RESTORE_CActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::RESTORE_CActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::RESTORE_CActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::RESTORE_CActivity::SampleDistribution(){
  return 0;
}

double* VERSION_2SAN::RESTORE_CActivity::ReturnDistributionParameters(){
    return NULL;
}

int VERSION_2SAN::RESTORE_CActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::RESTORE_CActivity::Fire(){
  (*(REPAIRING_SYSTEM_Mobius_Mark))--;
  (*(BUFFER_C_Mobius_Mark))--;
  (*(REPAIRING_SYSTEM_Mobius_Mark))++;
  (*(PLACE_C_Mobius_Mark))++;
  return this;
}

/*======================STOP_RESTOREActivity========================*/


VERSION_2SAN::STOP_RESTOREActivity::STOP_RESTOREActivity(){
  ActivityInitialize("STOP_RESTORE",12,Instantaneous , RaceEnabled, 2,4, false);
}

void VERSION_2SAN::STOP_RESTOREActivity::LinkVariables(){
  BUFFER_A->Register(&BUFFER_A_Mobius_Mark);
  BUFFER_B->Register(&BUFFER_B_Mobius_Mark);
  BUFFER_C->Register(&BUFFER_C_Mobius_Mark);
  REPAIRING_SYSTEM->Register(&REPAIRING_SYSTEM_Mobius_Mark);
  WORKING_SYSTEM->Register(&WORKING_SYSTEM_Mobius_Mark);
}

bool VERSION_2SAN::STOP_RESTOREActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((BUFFER_A->Mark() == 0) && (BUFFER_B->Mark() == 0) && (BUFFER_C->Mark() == 0) && (REPAIRING_SYSTEM->Mark() == 1)));
  return NewEnabled;
}

double VERSION_2SAN::STOP_RESTOREActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::STOP_RESTOREActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::STOP_RESTOREActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::STOP_RESTOREActivity::SampleDistribution(){
  return 0;
}

double* VERSION_2SAN::STOP_RESTOREActivity::ReturnDistributionParameters(){
    return NULL;
}

int VERSION_2SAN::STOP_RESTOREActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::STOP_RESTOREActivity::Fire(){
  REPAIRING_SYSTEM->Mark()--;
  WORKING_SYSTEM -> Mark() = 1;
  return this;
}

/*======================FAIL_AActivity========================*/

VERSION_2SAN::FAIL_AActivity::FAIL_AActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("FAIL_A",0,Exponential, RaceEnabled, 4,2, false);
}

VERSION_2SAN::FAIL_AActivity::~FAIL_AActivity(){
  delete[] TheDistributionParameters;
}

void VERSION_2SAN::FAIL_AActivity::LinkVariables(){
  PLACE_A->Register(&PLACE_A_Mobius_Mark);
  WORKING_SYSTEM->Register(&WORKING_SYSTEM_Mobius_Mark);
  BUFFER_A->Register(&BUFFER_A_Mobius_Mark);
  FAILED_A->Register(&FAILED_A_Mobius_Mark);
  SYSTEM_FAILURE->Register(&SYSTEM_FAILURE_Mobius_Mark);
}

bool VERSION_2SAN::FAIL_AActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(PLACE_A_Mobius_Mark)) >=1)&&(WORKING_SYSTEM -> Mark() == 1));
  return NewEnabled;
}

double VERSION_2SAN::FAIL_AActivity::Rate(){
  return lambda/4.00;
  return 1.0;  // default rate if none is specified
}

double VERSION_2SAN::FAIL_AActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::FAIL_AActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::FAIL_AActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::FAIL_AActivity::SampleDistribution(){
  return TheDistribution->Exponential(lambda/4.00);
}

double* VERSION_2SAN::FAIL_AActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int VERSION_2SAN::FAIL_AActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::FAIL_AActivity::Fire(){
  ;
  (*(PLACE_A_Mobius_Mark))--;
  (*(BUFFER_A_Mobius_Mark))++;
  (*(FAILED_A_Mobius_Mark))++;
  (*(SYSTEM_FAILURE_Mobius_Mark))++;
  return this;
}

/*======================REPAIR_ACT_AActivity========================*/

VERSION_2SAN::REPAIR_ACT_AActivity::REPAIR_ACT_AActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("REPAIR_ACT_A",1,Exponential, RaceEnabled, 1,3, false);
}

VERSION_2SAN::REPAIR_ACT_AActivity::~REPAIR_ACT_AActivity(){
  delete[] TheDistributionParameters;
}

void VERSION_2SAN::REPAIR_ACT_AActivity::LinkVariables(){
  FAILED_A->Register(&FAILED_A_Mobius_Mark);
  SYSTEM_MAINTAINANCE->Register(&SYSTEM_MAINTAINANCE_Mobius_Mark);
  FAILED_B->Register(&FAILED_B_Mobius_Mark);
}

bool VERSION_2SAN::REPAIR_ACT_AActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((FAILED_A->Mark() >= 1) && (SYSTEM_MAINTAINANCE->Mark() == 1) && (FAILED_B->Mark() == 0) && (FAILED_A->Mark() == 0)

));
  return NewEnabled;
}

double VERSION_2SAN::REPAIR_ACT_AActivity::Rate(){
  return mu/4.00;
  return 1.0;  // default rate if none is specified
}

double VERSION_2SAN::REPAIR_ACT_AActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::REPAIR_ACT_AActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::REPAIR_ACT_AActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::REPAIR_ACT_AActivity::SampleDistribution(){
  return TheDistribution->Exponential(mu/4.00);
}

double* VERSION_2SAN::REPAIR_ACT_AActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int VERSION_2SAN::REPAIR_ACT_AActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::REPAIR_ACT_AActivity::Fire(){
  FAILED_A->Mark()--;
  return this;
}

/*======================FAIL_BActivity========================*/

VERSION_2SAN::FAIL_BActivity::FAIL_BActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("FAIL_B",2,Exponential, RaceEnabled, 4,2, false);
}

VERSION_2SAN::FAIL_BActivity::~FAIL_BActivity(){
  delete[] TheDistributionParameters;
}

void VERSION_2SAN::FAIL_BActivity::LinkVariables(){
  PLACE_B->Register(&PLACE_B_Mobius_Mark);
  WORKING_SYSTEM->Register(&WORKING_SYSTEM_Mobius_Mark);
  FAILED_B->Register(&FAILED_B_Mobius_Mark);
  FAILED_B_C->Register(&FAILED_B_C_Mobius_Mark);
  BUFFER_B->Register(&BUFFER_B_Mobius_Mark);
}

bool VERSION_2SAN::FAIL_BActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(PLACE_B_Mobius_Mark)) >=1)&&(WORKING_SYSTEM -> Mark() == 1));
  return NewEnabled;
}

double VERSION_2SAN::FAIL_BActivity::Rate(){
  return lambda*(PLACE_B->Mark())/2.00;
  return 1.0;  // default rate if none is specified
}

double VERSION_2SAN::FAIL_BActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::FAIL_BActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::FAIL_BActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::FAIL_BActivity::SampleDistribution(){
  return TheDistribution->Exponential(lambda*(PLACE_B->Mark())/2.00);
}

double* VERSION_2SAN::FAIL_BActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int VERSION_2SAN::FAIL_BActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::FAIL_BActivity::Fire(){
  ;
  (*(PLACE_B_Mobius_Mark))--;
  (*(FAILED_B_Mobius_Mark))++;
  (*(FAILED_B_C_Mobius_Mark))++;
  (*(BUFFER_B_Mobius_Mark))++;
  return this;
}

/*======================REPAIR_ACT_BActivity========================*/

VERSION_2SAN::REPAIR_ACT_BActivity::REPAIR_ACT_BActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("REPAIR_ACT_B",3,Exponential, RaceEnabled, 1,3, false);
}

VERSION_2SAN::REPAIR_ACT_BActivity::~REPAIR_ACT_BActivity(){
  delete[] TheDistributionParameters;
}

void VERSION_2SAN::REPAIR_ACT_BActivity::LinkVariables(){
  FAILED_B->Register(&FAILED_B_Mobius_Mark);
  SYSTEM_MAINTAINANCE->Register(&SYSTEM_MAINTAINANCE_Mobius_Mark);
  FAILED_C->Register(&FAILED_C_Mobius_Mark);
}

bool VERSION_2SAN::REPAIR_ACT_BActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((FAILED_B->Mark() >= 1) && (SYSTEM_MAINTAINANCE->Mark() == 1) && FAILED_C ->Mark() == 0));
  return NewEnabled;
}

double VERSION_2SAN::REPAIR_ACT_BActivity::Rate(){
  return mu/2.00;
  return 1.0;  // default rate if none is specified
}

double VERSION_2SAN::REPAIR_ACT_BActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::REPAIR_ACT_BActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::REPAIR_ACT_BActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::REPAIR_ACT_BActivity::SampleDistribution(){
  return TheDistribution->Exponential(mu/2.00);
}

double* VERSION_2SAN::REPAIR_ACT_BActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int VERSION_2SAN::REPAIR_ACT_BActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::REPAIR_ACT_BActivity::Fire(){
  FAILED_B->Mark()--;
  return this;
}

/*======================REPAIR_C_ACTActivity========================*/

VERSION_2SAN::REPAIR_C_ACTActivity::REPAIR_C_ACTActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("REPAIR_C_ACT",4,Exponential, RaceEnabled, 1,2, false);
}

VERSION_2SAN::REPAIR_C_ACTActivity::~REPAIR_C_ACTActivity(){
  delete[] TheDistributionParameters;
}

void VERSION_2SAN::REPAIR_C_ACTActivity::LinkVariables(){
  SYSTEM_MAINTAINANCE->Register(&SYSTEM_MAINTAINANCE_Mobius_Mark);
  FAILED_C->Register(&FAILED_C_Mobius_Mark);
}

bool VERSION_2SAN::REPAIR_C_ACTActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=((


(FAILED_C -> Mark() == 1) && (SYSTEM_MAINTAINANCE -> Mark()== 1)));
  return NewEnabled;
}

double VERSION_2SAN::REPAIR_C_ACTActivity::Rate(){
  return mu;
  return 1.0;  // default rate if none is specified
}

double VERSION_2SAN::REPAIR_C_ACTActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::REPAIR_C_ACTActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::REPAIR_C_ACTActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::REPAIR_C_ACTActivity::SampleDistribution(){
  return TheDistribution->Exponential(mu);
}

double* VERSION_2SAN::REPAIR_C_ACTActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int VERSION_2SAN::REPAIR_C_ACTActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::REPAIR_C_ACTActivity::Fire(){
  FAILED_C->Mark()--;
  return this;
}

/*======================FAIL_CActivity========================*/

VERSION_2SAN::FAIL_CActivity::FAIL_CActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("FAIL_C",5,Exponential, RaceEnabled, 4,2, false);
}

VERSION_2SAN::FAIL_CActivity::~FAIL_CActivity(){
  delete[] TheDistributionParameters;
}

void VERSION_2SAN::FAIL_CActivity::LinkVariables(){
  PLACE_C->Register(&PLACE_C_Mobius_Mark);
  WORKING_SYSTEM->Register(&WORKING_SYSTEM_Mobius_Mark);
  FAILED_B_C->Register(&FAILED_B_C_Mobius_Mark);
  BUFFER_C->Register(&BUFFER_C_Mobius_Mark);
  FAILED_C->Register(&FAILED_C_Mobius_Mark);
}

bool VERSION_2SAN::FAIL_CActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(PLACE_C_Mobius_Mark)) >=1)&&(WORKING_SYSTEM -> Mark() == 1));
  return NewEnabled;
}

double VERSION_2SAN::FAIL_CActivity::Rate(){
  return lambda*(PLACE_C->Mark() );
  return 1.0;  // default rate if none is specified
}

double VERSION_2SAN::FAIL_CActivity::Weight(){ 
  return 1;
}

bool VERSION_2SAN::FAIL_CActivity::ReactivationPredicate(){ 
  return false;
}

bool VERSION_2SAN::FAIL_CActivity::ReactivationFunction(){ 
  return false;
}

double VERSION_2SAN::FAIL_CActivity::SampleDistribution(){
  return TheDistribution->Exponential(lambda*(PLACE_C->Mark() ));
}

double* VERSION_2SAN::FAIL_CActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = Rate();
  return TheDistributionParameters;
}

int VERSION_2SAN::FAIL_CActivity::Rank(){
  return 1;
}

BaseActionClass* VERSION_2SAN::FAIL_CActivity::Fire(){
  ;
  (*(PLACE_C_Mobius_Mark))--;
  (*(FAILED_B_C_Mobius_Mark))++;
  (*(BUFFER_C_Mobius_Mark))++;
  (*(FAILED_C_Mobius_Mark))++;
  return this;
}

