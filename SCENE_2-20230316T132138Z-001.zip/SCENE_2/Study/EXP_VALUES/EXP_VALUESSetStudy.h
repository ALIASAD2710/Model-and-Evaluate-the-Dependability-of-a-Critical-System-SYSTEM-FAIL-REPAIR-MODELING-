
#ifndef EXP_VALUESSetSTUDY_H_
#define EXP_VALUESSetSTUDY_H_

#include "Reward/VERSION_2FS/VERSION_2FSPVNodes.h"
#include "Reward/VERSION_2FS/VERSION_2FSPVModel.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern Double lambda;
extern Double mu;

class EXP_VALUESSetStudy : public BaseStudyClass {
public:

EXP_VALUESSetStudy();
~EXP_VALUESSetStudy();

private:

double *lambdaValues;
double *muValues;

void SetValues_lambda();
void SetValues_mu();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

