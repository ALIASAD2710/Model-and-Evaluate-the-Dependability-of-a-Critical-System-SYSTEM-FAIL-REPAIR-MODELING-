
#ifndef FRSYSTEMSetSTUDY_H_
#define FRSYSTEMSetSTUDY_H_

#include "Reward/FAIL_SAFE_SYSTEM/FAIL_SAFE_SYSTEMPVNodes.h"
#include "Reward/FAIL_SAFE_SYSTEM/FAIL_SAFE_SYSTEMPVModel.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern Double lambda;
extern Double mu;

class FRSYSTEMSetStudy : public BaseStudyClass {
public:

FRSYSTEMSetStudy();
~FRSYSTEMSetStudy();

private:

double *lambdaValues;
double *muValues;

void SetValues_lambda();
void SetValues_mu();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

