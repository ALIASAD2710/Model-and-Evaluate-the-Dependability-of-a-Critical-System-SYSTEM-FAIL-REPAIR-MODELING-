#ifndef _FAIL_SAFE_SYSTEM_PVS_
#define _FAIL_SAFE_SYSTEM_PVS_
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Atomic/REPAIR_SYSTEM_2/REPAIR_SYSTEM_2SAN.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"
#include "Cpp/Performance_Variables/SteadyState.hpp"


class FAIL_SAFE_SYSTEMPV0Worker:public InstantOfTime
{
 public:
  REPAIR_SYSTEM_2SAN *REPAIR_SYSTEM_2;
  
  FAIL_SAFE_SYSTEMPV0Worker();
  ~FAIL_SAFE_SYSTEMPV0Worker();
  double Reward_Function();
};

class FAIL_SAFE_SYSTEMPV0:public PerformanceVariableNode
{
 public:
  REPAIR_SYSTEM_2SAN *TheREPAIR_SYSTEM_2SAN;

  FAIL_SAFE_SYSTEMPV0Worker *FAIL_SAFE_SYSTEMPV0WorkerList;

  FAIL_SAFE_SYSTEMPV0(int timeindex=0);
  ~FAIL_SAFE_SYSTEMPV0();
  void CreateWorkerList(void);
};

class FAIL_SAFE_SYSTEMPV1Worker:public SteadyState
{
 public:
  REPAIR_SYSTEM_2SAN *REPAIR_SYSTEM_2;
  
  FAIL_SAFE_SYSTEMPV1Worker();
  ~FAIL_SAFE_SYSTEMPV1Worker();
  double Reward_Function();
};

class FAIL_SAFE_SYSTEMPV1:public PerformanceVariableNode
{
 public:
  REPAIR_SYSTEM_2SAN *TheREPAIR_SYSTEM_2SAN;

  FAIL_SAFE_SYSTEMPV1Worker *FAIL_SAFE_SYSTEMPV1WorkerList;

  FAIL_SAFE_SYSTEMPV1(int timeindex=0);
  ~FAIL_SAFE_SYSTEMPV1();
  void CreateWorkerList(void);
};

#endif
