#ifndef _FAIL_SAFE_SYSTEM_PVMODEL_
#define _FAIL_SAFE_SYSTEM_PVMODEL_
#include "FAIL_SAFE_SYSTEMPVNodes.h"
#include "Cpp/Performance_Variables/PVModel.hpp"
#include "Atomic/REPAIR_SYSTEM_2/REPAIR_SYSTEM_2SAN.h"
class FAIL_SAFE_SYSTEMPVModel:public PVModel {
 protected:
  PerformanceVariableNode *createPVNode(int pvindex, int timeindex);
 public:
  FAIL_SAFE_SYSTEMPVModel(bool expandtimepoints);
};

#endif
