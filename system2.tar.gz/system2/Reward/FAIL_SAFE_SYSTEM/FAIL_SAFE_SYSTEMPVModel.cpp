#include "FAIL_SAFE_SYSTEMPVModel.h"

FAIL_SAFE_SYSTEMPVModel::FAIL_SAFE_SYSTEMPVModel(bool expandTimeArrays) {
  TheModel=new REPAIR_SYSTEM_2SAN();
  DefineName("FAIL_SAFE_SYSTEMPVModel");
  CreatePVList(2, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* FAIL_SAFE_SYSTEMPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new FAIL_SAFE_SYSTEMPV0(timeindex);
    break;
  case 1:
    return new FAIL_SAFE_SYSTEMPV1(timeindex);
    break;
  }
  return NULL;
}
