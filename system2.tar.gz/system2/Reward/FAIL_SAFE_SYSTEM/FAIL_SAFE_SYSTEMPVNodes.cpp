#include "FAIL_SAFE_SYSTEMPVNodes.h"

FAIL_SAFE_SYSTEMPV0Worker::FAIL_SAFE_SYSTEMPV0Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&REPAIR_SYSTEM_2);
}

FAIL_SAFE_SYSTEMPV0Worker::~FAIL_SAFE_SYSTEMPV0Worker() {
  delete [] TheModelPtr;
}

double FAIL_SAFE_SYSTEMPV0Worker::Reward_Function(void) {

if (1 > REPAIR_SYSTEM_2->FAILURE_BUFFER->Mark()) return 1;

return (0);



}

FAIL_SAFE_SYSTEMPV0::FAIL_SAFE_SYSTEMPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheREPAIR_SYSTEM_2SAN);
  double startpts[144]={24, 360, 1080, 3600, 5400, 11160, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  double stoppts[144]={24, 360, 1080, 3600, 5400, 11160, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  Initialize("RELIABILITY",(RewardType)0,144, startpts, stoppts, timeindex, 0,1, 1);
  AddVariableDependency("FAILURE_BUFFER","REPAIR_SYSTEM_2");
}

FAIL_SAFE_SYSTEMPV0::~FAIL_SAFE_SYSTEMPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void FAIL_SAFE_SYSTEMPV0::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new FAIL_SAFE_SYSTEMPV0Worker;
}
FAIL_SAFE_SYSTEMPV1Worker::FAIL_SAFE_SYSTEMPV1Worker()
{
  NumModels = 1;
  TheModelPtr = new BaseModelClass**[NumModels];
  TheModelPtr[0] = (BaseModelClass**)(&REPAIR_SYSTEM_2);
}

FAIL_SAFE_SYSTEMPV1Worker::~FAIL_SAFE_SYSTEMPV1Worker() {
  delete [] TheModelPtr;
}

double FAIL_SAFE_SYSTEMPV1Worker::Reward_Function(void) {

if (REPAIR_SYSTEM_2->WORKING_SYSTEM->Mark()>0) return 1;

return (0);



}

FAIL_SAFE_SYSTEMPV1::FAIL_SAFE_SYSTEMPV1(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&TheREPAIR_SYSTEM_2SAN);
  double startpts[1]={0.0};
  double stoppts[1]={0.0+1.0};
  Initialize("AVAILABILITY",(RewardType)3,1, startpts, stoppts, timeindex, 0,1, 1);
  Type = steady_state;
  AddVariableDependency("WORKING_SYSTEM","REPAIR_SYSTEM_2");
}

FAIL_SAFE_SYSTEMPV1::~FAIL_SAFE_SYSTEMPV1() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void FAIL_SAFE_SYSTEMPV1::CreateWorkerList(void) {
  for(int i = 0; i < NumberOfWorkers; i++)
    WorkerList[i] = new FAIL_SAFE_SYSTEMPV1Worker;
}
