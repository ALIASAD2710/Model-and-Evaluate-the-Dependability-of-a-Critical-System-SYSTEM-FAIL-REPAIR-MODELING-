#ifndef _VERSION_2FS_PVS_
#define _VERSION_2FS_PVS_
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Atomic/VERSION_2/VERSION_2SAN.h"
#include "Cpp/Performance_Variables/InstantOfTime.hpp"


class VERSION_2FSPV0Worker:public InstantOfTime
{
 public:
  VERSION_2SAN *VERSION_2;
  
  VERSION_2FSPV0Worker();
  ~VERSION_2FSPV0Worker();
  double Reward_Function();
};

class VERSION_2FSPV0:public PerformanceVariableNode
{
 public:
  VERSION_2SAN *TheVERSION_2SAN;

  VERSION_2FSPV0Worker *VERSION_2FSPV0WorkerList;

  VERSION_2FSPV0(int timeindex=0);
  ~VERSION_2FSPV0();
  void CreateWorkerList(void);
};

class VERSION_2FSPV1Worker:public InstantOfTime
{
 public:
  VERSION_2SAN *VERSION_2;
  
  VERSION_2FSPV1Worker();
  ~VERSION_2FSPV1Worker();
  double Reward_Function();
};

class VERSION_2FSPV1:public PerformanceVariableNode
{
 public:
  VERSION_2SAN *TheVERSION_2SAN;

  VERSION_2FSPV1Worker *VERSION_2FSPV1WorkerList;

  VERSION_2FSPV1(int timeindex=0);
  ~VERSION_2FSPV1();
  void CreateWorkerList(void);
};

#endif
