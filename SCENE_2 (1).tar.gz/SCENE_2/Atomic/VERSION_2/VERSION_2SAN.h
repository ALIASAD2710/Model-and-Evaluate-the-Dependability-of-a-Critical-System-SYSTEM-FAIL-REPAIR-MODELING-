#ifndef VERSION_2SAN_H_
#define VERSION_2SAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Double lambda;
extern Double mu;
extern UserDistributions* TheDistribution;

void MemoryError();


/*********************************************************************
               VERSION_2SAN Submodel Definition                   
*********************************************************************/

class VERSION_2SAN:public SANModel{
public:

class RESTORE_AActivity:public Activity {
public:

  Place* BUFFER_A;
  short* BUFFER_A_Mobius_Mark;
  Place* REPAIRING_SYSTEM;
  short* REPAIRING_SYSTEM_Mobius_Mark;
  Place* PLACE_A;
  short* PLACE_A_Mobius_Mark;

  double* TheDistributionParameters;
  RESTORE_AActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // RESTORE_AActivityActivity

class REPAIR_STARTActivity:public Activity {
public:

  Place* SYSTEM_FAILURE;
  short* SYSTEM_FAILURE_Mobius_Mark;
  Place* WORKING_SYSTEM;
  short* WORKING_SYSTEM_Mobius_Mark;
  Place* SYSTEM_MAINTAINANCE;
  short* SYSTEM_MAINTAINANCE_Mobius_Mark;
  Place* FAILURE_BUFFER;
  short* FAILURE_BUFFER_Mobius_Mark;

  double* TheDistributionParameters;
  REPAIR_STARTActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // REPAIR_STARTActivityActivity

class RESTORE_BActivity:public Activity {
public:

  Place* REPAIRING_SYSTEM;
  short* REPAIRING_SYSTEM_Mobius_Mark;
  Place* BUFFER_B;
  short* BUFFER_B_Mobius_Mark;
  Place* PLACE_B;
  short* PLACE_B_Mobius_Mark;

  double* TheDistributionParameters;
  RESTORE_BActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // RESTORE_BActivityActivity

class REPAIR_FINISHEDActivity:public Activity {
public:

  Place* FAILED_A;
  short* FAILED_A_Mobius_Mark;
  Place* SYSTEM_MAINTAINANCE;
  short* SYSTEM_MAINTAINANCE_Mobius_Mark;
  Place* FAILED_C;
  short* FAILED_C_Mobius_Mark;
  Place* FAILED_B;
  short* FAILED_B_Mobius_Mark;
  Place* REPAIRING_SYSTEM;
  short* REPAIRING_SYSTEM_Mobius_Mark;

  double* TheDistributionParameters;
  REPAIR_FINISHEDActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // REPAIR_FINISHEDActivityActivity

class SYSTEM_FAILURE_B_CActivity:public Activity {
public:

  Place* FAILED_B_C;
  short* FAILED_B_C_Mobius_Mark;
  Place* SYSTEM_FAILURE;
  short* SYSTEM_FAILURE_Mobius_Mark;

  double* TheDistributionParameters;
  SYSTEM_FAILURE_B_CActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // SYSTEM_FAILURE_B_CActivityActivity

class RESTORE_CActivity:public Activity {
public:

  Place* REPAIRING_SYSTEM;
  short* REPAIRING_SYSTEM_Mobius_Mark;
  Place* BUFFER_C;
  short* BUFFER_C_Mobius_Mark;
  Place* PLACE_C;
  short* PLACE_C_Mobius_Mark;

  double* TheDistributionParameters;
  RESTORE_CActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // RESTORE_CActivityActivity

class STOP_RESTOREActivity:public Activity {
public:

  Place* BUFFER_A;
  short* BUFFER_A_Mobius_Mark;
  Place* BUFFER_B;
  short* BUFFER_B_Mobius_Mark;
  Place* BUFFER_C;
  short* BUFFER_C_Mobius_Mark;
  Place* REPAIRING_SYSTEM;
  short* REPAIRING_SYSTEM_Mobius_Mark;
  Place* WORKING_SYSTEM;
  short* WORKING_SYSTEM_Mobius_Mark;

  double* TheDistributionParameters;
  STOP_RESTOREActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // STOP_RESTOREActivityActivity

class FAIL_AActivity:public Activity {
public:

  Place* PLACE_A;
  short* PLACE_A_Mobius_Mark;
  Place* WORKING_SYSTEM;
  short* WORKING_SYSTEM_Mobius_Mark;
  Place* BUFFER_A;
  short* BUFFER_A_Mobius_Mark;
  Place* FAILED_A;
  short* FAILED_A_Mobius_Mark;
  Place* SYSTEM_FAILURE;
  short* SYSTEM_FAILURE_Mobius_Mark;

  double* TheDistributionParameters;
  FAIL_AActivity();
  ~FAIL_AActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // FAIL_AActivityActivity

class REPAIR_ACT_AActivity:public Activity {
public:

  Place* FAILED_A;
  short* FAILED_A_Mobius_Mark;
  Place* SYSTEM_MAINTAINANCE;
  short* SYSTEM_MAINTAINANCE_Mobius_Mark;
  Place* FAILED_B;
  short* FAILED_B_Mobius_Mark;

  double* TheDistributionParameters;
  REPAIR_ACT_AActivity();
  ~REPAIR_ACT_AActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // REPAIR_ACT_AActivityActivity

class FAIL_BActivity:public Activity {
public:

  Place* PLACE_B;
  short* PLACE_B_Mobius_Mark;
  Place* WORKING_SYSTEM;
  short* WORKING_SYSTEM_Mobius_Mark;
  Place* FAILED_B;
  short* FAILED_B_Mobius_Mark;
  Place* FAILED_B_C;
  short* FAILED_B_C_Mobius_Mark;
  Place* BUFFER_B;
  short* BUFFER_B_Mobius_Mark;

  double* TheDistributionParameters;
  FAIL_BActivity();
  ~FAIL_BActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // FAIL_BActivityActivity

class REPAIR_ACT_BActivity:public Activity {
public:

  Place* FAILED_B;
  short* FAILED_B_Mobius_Mark;
  Place* SYSTEM_MAINTAINANCE;
  short* SYSTEM_MAINTAINANCE_Mobius_Mark;
  Place* FAILED_C;
  short* FAILED_C_Mobius_Mark;

  double* TheDistributionParameters;
  REPAIR_ACT_BActivity();
  ~REPAIR_ACT_BActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // REPAIR_ACT_BActivityActivity

class REPAIR_C_ACTActivity:public Activity {
public:

  Place* SYSTEM_MAINTAINANCE;
  short* SYSTEM_MAINTAINANCE_Mobius_Mark;
  Place* FAILED_C;
  short* FAILED_C_Mobius_Mark;

  double* TheDistributionParameters;
  REPAIR_C_ACTActivity();
  ~REPAIR_C_ACTActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // REPAIR_C_ACTActivityActivity

class FAIL_CActivity:public Activity {
public:

  Place* PLACE_C;
  short* PLACE_C_Mobius_Mark;
  Place* WORKING_SYSTEM;
  short* WORKING_SYSTEM_Mobius_Mark;
  Place* FAILED_B_C;
  short* FAILED_B_C_Mobius_Mark;
  Place* BUFFER_C;
  short* BUFFER_C_Mobius_Mark;
  Place* FAILED_C;
  short* FAILED_C_Mobius_Mark;

  double* TheDistributionParameters;
  FAIL_CActivity();
  ~FAIL_CActivity();
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double Rate();
}; // FAIL_CActivityActivity

  //List of user-specified place names
  Place* BUFFER_A;
  Place* WORKING_SYSTEM;
  Place* FAILURE_BUFFER;
  Place* FAILED_A;
  Place* SYSTEM_FAILURE;
  Place* PLACE_A;
  Place* FAILED_B;
  Place* PLACE_B;
  Place* REPAIRING_SYSTEM;
  Place* SYSTEM_MAINTAINANCE;
  Place* FAILED_B_C;
  Place* BUFFER_B;
  Place* PLACE_C;
  Place* BUFFER_C;
  Place* FAILED_C;

  // Create instances of all actvities
  RESTORE_AActivity RESTORE_A;
  REPAIR_STARTActivity REPAIR_START;
  RESTORE_BActivity RESTORE_B;
  REPAIR_FINISHEDActivity REPAIR_FINISHED;
  SYSTEM_FAILURE_B_CActivity SYSTEM_FAILURE_B_C;
  RESTORE_CActivity RESTORE_C;
  STOP_RESTOREActivity STOP_RESTORE;
  FAIL_AActivity FAIL_A;
  REPAIR_ACT_AActivity REPAIR_ACT_A;
  FAIL_BActivity FAIL_B;
  REPAIR_ACT_BActivity REPAIR_ACT_B;
  REPAIR_C_ACTActivity REPAIR_C_ACT;
  FAIL_CActivity FAIL_C;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup RESTORE_AGroup;
  PostselectGroup REPAIR_STARTGroup;
  PostselectGroup RESTORE_BGroup;
  PostselectGroup REPAIR_FINISHEDGroup;
  PostselectGroup SYSTEM_FAILURE_B_CGroup;
  PostselectGroup RESTORE_CGroup;
  PostselectGroup STOP_RESTOREGroup;

  VERSION_2SAN();
  ~VERSION_2SAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end VERSION_2SAN

#endif // VERSION_2SAN_H_
